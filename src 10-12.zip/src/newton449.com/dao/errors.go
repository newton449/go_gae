/*
Defines errors for dao package
*/

package dao

const (
	err = iota
)
